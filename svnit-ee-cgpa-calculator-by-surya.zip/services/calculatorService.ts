
import { Grade, GradePoints, Subject } from '../types';

/**
 * Calculates the SGPA based on provided grades and subject list.
 * @param subjects Array of subjects with credit information
 * @param grades Mapping of subject codes to assigned grades
 * @returns Object containing SGPA and calculation stats
 */
export const calculateSGPA = (
  subjects: Subject[],
  grades: Record<string, Grade>
) => {
  let totalPoints = 0;
  let totalCredits = 0;
  let earnedCredits = 0;

  subjects.forEach((sub) => {
    const grade = grades[sub.code] || Grade.NA;
    const points = GradePoints[grade];
    
    totalPoints += points * sub.credits;
    totalCredits += sub.credits;

    if (grade !== Grade.FF && grade !== Grade.NA) {
      earnedCredits += sub.credits;
    }
  });

  const sgpa = totalCredits > 0 ? totalPoints / totalCredits : 0;

  return {
    sgpa: Number(sgpa.toFixed(2)),
    totalCredits,
    earnedCredits,
    totalPoints
  };
};
