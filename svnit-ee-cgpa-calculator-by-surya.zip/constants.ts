
import { Subject } from './types';

export const THEME = {
  natureGreen: '#064e3b',
  circuitBlue: '#0ea5e9',
  copperGold: '#b45309',
  softMint: '#f0fdf4',
  deepForest: '#022c22'
};

export const FIRST_SEM_SUBJECTS: Subject[] = [
  { code: 'EE101 T', name: 'Basic Electrical Engineering (Theory)', credits: 4, type: 'Theory' },
  { code: 'EE101 P', name: 'Basic Electrical Engineering (Practical)', credits: 1, type: 'Practical' },
  { code: 'ME110 T', name: 'Engineering Drawing (Theory)', credits: 2, type: 'Theory' },
  { code: 'ME110 P', name: 'Engineering Drawing (Practical)', credits: 2, type: 'Practical' },
  { code: 'PH109 T', name: 'Fundamentals of Physics (Theory)', credits: 3, type: 'Theory' },
  { code: 'PH109 P', name: 'Fundamentals of Physics (Practical)', credits: 1, type: 'Practical' },
  { code: 'MA113 T', name: 'Mathematics-I', credits: 4, type: 'Theory' },
  { code: 'HS110 T', name: 'English and Professional Communication', credits: 4, type: 'Theory' }
];

export const TOTAL_CREDITS = FIRST_SEM_SUBJECTS.reduce((acc, sub) => acc + sub.credits, 0);
